"""VigileGuard API Package

Phase 3 implementation of the Security Audit Engine API layer.
Provides REST API endpoints for scan management, authentication, and reporting.
"""

__version__ = "3.0.0"
__author__ = "VigileGuard Team"