#!/bin/bash

echo "🛡️  VigileGuard Phase 3 Quick Start"
echo "=================================="

# Run installation
if [[ -f "install_phase3.sh" ]]; then
    echo "Running Phase 3 installation..."
    bash install_phase3.sh
else
    echo "❌ install_phase3.sh not found"
    exit 1
fi

echo ""
echo "🚀 Quick Start Options:"
echo ""
echo "1. Test local scanning:"
echo "   ./vigileguard-cli"
echo ""
echo "2. Start API server:"
echo "   ./vigileguard-api"
echo ""
echo "3. Test API mode:"
echo "   ./vigileguard-cli --target localhost --api-mode"
echo ""

