"""
VigileGuard API Server Entry Point
Allow running API server with: python -m api
"""

from .main import main

if __name__ == "__main__":
    main()